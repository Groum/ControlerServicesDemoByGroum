package com.example.H2implementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2implementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2implementationApplication.class, args);
	}

}
