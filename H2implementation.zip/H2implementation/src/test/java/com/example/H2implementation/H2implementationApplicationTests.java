package com.example.H2implementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2implementationApplicationTests {

	@Test
	void contextLoads() {
	}

}
